	The website of UniT itself is generated with 

	UniT - the Universal Text generator!

	Therefore the website is itself an application example for UniT.

	The file MakeStaticImage.unit is the main file,
	that directly or indirectly executes all other files of the example.

	This example demonstrates the most features of UniT
	especially nested UniTs, file inclusion and parameter passing.
	